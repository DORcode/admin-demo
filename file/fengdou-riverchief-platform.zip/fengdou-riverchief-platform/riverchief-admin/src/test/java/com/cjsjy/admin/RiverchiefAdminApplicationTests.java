package com.cjsjy.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiverchiefAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
